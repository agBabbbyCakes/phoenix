Phoenix Dashboard - Windows Standalone
======================================

Installation:
1. Extract this zip file to any location
2. Double-click PhoenixDashboard.exe to run
3. Your browser will automatically open to the dashboard

Usage:
- The dashboard runs on http://127.0.0.1:8000 by default
- Press Ctrl+C in the console window to stop
- You can access it from other devices using your computer's IP address

System Requirements:
- Windows 10 or later
- No Python installation required

For support, visit: https://github.com/agBabbbyCakes/phoenix
